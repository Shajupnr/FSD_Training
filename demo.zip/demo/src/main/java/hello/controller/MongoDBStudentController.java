package hello.controller;

import hello.DAO.MongoDBStudentServiceImp;
import hello.Model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

/**
 * Created by n0309472 on 7/11/2017.
 */
@RestController
@RequestMapping(value="/rest/student")
public class MongoDBStudentController {

    public static HashMap<Long,Student> hmStudent;
    @Autowired
    private  MongoDBStudentServiceImp service;
    MongoDBStudentController(MongoDBStudentServiceImp service) {
        this.service = service;
    }
    @RequestMapping(value="/",method = RequestMethod.GET)
    HashMap<Long,Student> findAll() {
        long lVal=1;
        for (Student objStudent : service.findAll()) {
            System.out.println(objStudent);
            hmStudent.put(lVal,objStudent);
            lVal++;
        }
        return hmStudent;
    }
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    void delete(@PathVariable("id") long id) {
        service.delete(id);
    }

    @RequestMapping(value="/update",method = RequestMethod.PUT)
    public void update(@RequestBody Student student) throws Exception {

        service.update(student);
    }



}
