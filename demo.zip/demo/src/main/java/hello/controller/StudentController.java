package hello.controller;

import hello.Model.Student;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by n0309472 on 7/6/2017.
 */
//@RestController
//@RequestMapping(value="/rest/student")
public class StudentController {


    public static HashMap<Long,Student> hmStudent;
    StudentController(){
    hmStudent=new HashMap<Long,Student>();
        Student objStudent;
        objStudent=new Student(1,"Shaju","CS");
        hmStudent.put(Long.valueOf(1),objStudent);
        objStudent=new Student(2,"Ajith","EC");
        hmStudent.put(Long.valueOf(2),objStudent);
        objStudent=new Student(3,"Sudharshan","MC");
        hmStudent.put(Long.valueOf(3),objStudent);
    }


    @RequestMapping(value="/",method = RequestMethod.GET)
    public HashMap<Long,Student> getAllStudents(){
        return hmStudent;
    }

    @RequestMapping(value="/add",method = RequestMethod.POST)
    public Student addStudent(@RequestParam(value="name") String name
            ,@RequestParam(value="subject",defaultValue = "unknown") String subject){

        Student student=new Student(101,name,subject);
        hmStudent.put(Long.valueOf(4),student);
        return student;

    }

    @RequestMapping(value="/update",method = RequestMethod.PUT)
    public Student updateStudent(@RequestBody Student student) throws Exception {

        if(hmStudent.containsKey(new Long(student.getId()))){
            hmStudent.put(new Long(student.getId()),student);
        }else{
            throw new Exception("Student "+student.getId()+" does not exists");
        }

        return student;
    }
    @RequestMapping(value="/delete/{id}",method = RequestMethod.DELETE)
    public Student deleteStudent(@PathVariable long id) throws Exception {

        Student student;

        if(hmStudent.containsKey(new Long(id))){
            student=hmStudent.get(new Long(id));
            hmStudent.remove(new Long(id));
        }else{
            throw new Exception("Student "+id+" does not exists");
        }
        return student;
    }


}
