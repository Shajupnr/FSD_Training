package hello.controller;

import hello.Model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * Created by n0309472 on 7/11/2017.
 */
public interface  StudentRepository extends MongoRepository<Student, String> {

    public List<Student> findAll();
    public List<Student> findBySubject();
   // public void addStudent(Student st);
    public Student  save(Student st);
    public void delete(Student st);
    public  Student findById(Long Id);

}

