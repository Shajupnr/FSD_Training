package hello.DAO;

import hello.Model.Student;

import java.util.List;

/**
 * Created by n0309472 on 7/11/2017.
 */
public interface StudentService {

    public Student findByFirstName(String firstName);
    public List<Student> findAll();
    public List<Student> findBySubject(String strSubject);
    public void addStudent(Student st);
    public void update(Student st);
    public void delete(long Id);
    public  Student findById(Long Id);
}
