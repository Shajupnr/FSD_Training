package hello.DAO;

import hello.Model.Student;
import hello.controller.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

/**
 * Created by n0309472 on 7/11/2017.
 */
@Service
public class MongoDBStudentServiceImp implements StudentService {
    public static HashMap<Long,Student> hmStudent;

    @Autowired
    private  StudentRepository repository;

    Long lVal= Long.valueOf(1);

    @Override
    public Student findByFirstName(String firstName) {
        return null;
    }

    @Override
    public List<Student> findAll() {
        List<Student> studEntries = repository.findAll();
        return studEntries;
    }

    @Override
    public List<Student> findBySubject(String strSubject) {

        List<Student> studEntries = repository.findBySubject();
        return studEntries;
    }

    @Override
    public void addStudent(Student st) {
        repository.save(st);
    }

    @Override
    public void update(Student st) {

         repository.save(st);
    }

    @Override
    public void delete(long Id) {
        Student deleted = findById(Id);
        repository.delete(deleted);
    }

    @Override
    public Student findById(Long Id) {
        Student found = findById(Id);
        return found;

    }

    private  HashMap<Long,Student> convertToMap(List<Student> sLst) {
        long lVal=1;
        for (Student objStudent : sLst) {
           hmStudent.put(lVal,objStudent);
            lVal++;
        }
        return hmStudent;
    }


}
